<p><strong>Name:</strong> {{ $formData['name'] }}</p>
<p><strong>Email:</strong> {{ $formData['email'] }}</p>
<p><strong>Subject:</strong> {{ $formData['subject'] }}</p>
<p><strong>Message:</strong><br>{{ $formData['message'] }}</p>
