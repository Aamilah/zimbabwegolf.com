<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Edit A Player']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Edit A Player')]); ?>
    <div>
        <a href="<?php echo e(route('admin.players.index')); ?>">
            <button class="inverted-corner-btn z-50 absolute right-15"> Back
            <i class="ml-10 fa-solid fa-arrow-left"></i>
            </button>
        </a>
        <a href="<?php echo e(route('admin.admin-dashboard')); ?>">
            <button class="inverted-corner-btn w-10 h-10 items-center justify-center z-50 absolute right-50"><i class="fa-solid fa-home"></i>
            </button>
        </a>
        <div class="inverted-radius relative">
            <div class="inverted-radius-content">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <div class="frame-dot green-bg"></div>
                    <div class="frame-dot gold-bg"></div>
                    <div class="frame-dot red-bg"></div>
                </div>
                <div class="frame-wrapper">
                    <form action="<?php echo e(route('admin.players.update', $player->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" id="name" class="form-input" value="<?php echo e(old('name', $player->name)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="date_of_birth" class="form-label">Date of Birth</label>
                            <input type="date" name="date_of_birth" id="date_of_birth" class="form-input" value="<?php echo e(old('date_of_birth', $player->date_of_birth)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="place_of_birth" class="form-label">Place of Birth</label>
                            <input type="text" name="place_of_birth" id="place_of_birth" class="form-input" value="<?php echo e(old('place_of_birth', $player->place_of_birth)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="handicap" class="form-label">Handicap</label>
                            <input type="text" name="handicap" id="handicap" class="form-input" value="<?php echo e(old('handicap', $player->handicap)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="club" class="form-label">Club</label>
                            <input type="text" name="club" id="club" class="form-input" value="<?php echo e(old('club', $player->club)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="achievements" class="form-label">Achievements</label>
                            <textarea name="achievements" 
                                    id="achievements" 
                                    rows="5" 
                                    required
                                    class="form-input"><?php echo e(old('achievements', $player->achievements)); ?></textarea>
                        </div>
                        <div class="my-4">
                            <label for="owar" class="form-label">OWAR</label>
                            <input type="number" name="owar" id="owar" class="form-input" value="<?php echo e(old('owar', $player->owar)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="total_tournaments" class="form-label">Total Tournaments</label>
                            <input type="number" name="total_tournaments" id="total_tournaments" class="form-input" value="<?php echo e(old('total_tournaments', $player->total_tournaments)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="image_path" class="form-label">Image</label>

                            <?php
                                $image = $player->image_path 
                                    ? asset('storage/' . $player->image_path)
                                    : asset('images/default-player.jpg'); // <- path to your default image
                            ?>

                            <div class="mb-2">
                                <img src="<?php echo e($image); ?>" 
                                    alt="<?php echo e($player->name); ?>" 
                                    class="w-20 h-20 rounded-full object-cover border" />
                            </div>

                            <input
                                type="file"
                                name="image_path"
                                id="image_path"
                                accept="image/*"
                                class="form-input
                                    file:mr-4 file:py-2 file:px-4
                                    file:rounded-[200px] file:border-0
                                    file:text-sm file:font-semibold
                                    file:bg-green-500 file:text-white
                                    hover:file:bg-green-700
                                    focus:outline-none focus:ring focus:border-green"
                            >
                        </div>

       
                        <div class="my-4"><button class="green-red-btn">Update Player <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\players\edit.blade.php ENDPATH**/ ?>