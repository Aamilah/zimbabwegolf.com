<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['blog', 'href' => '#']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['blog', 'href' => '#']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="rounded-2xl border shadow-sm overflow-hidden p-2 flex flex-col justify-between mb-4">
  <div class="rounded-xl overflow-hidden">
    <img src="<?php echo e(asset('storage/' . $blog->thumbnail)); ?>"
         alt="<?php echo e($blog->image_caption); ?>"
         class="w-full h-64 object-cover">
  </div>

  <div class="post-headline">
    <?php echo e($blog->headline); ?>

  </div>

  <div class="flex items-center justify-between mt-3 text-[0.7rem]">
    <div class="flex gap-1">
      <span class="bg-[color:var(--red)] text-white px-3 py-2 rounded-full">
        <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d M, Y')); ?>

      </span>
      <span class="bg-[color:var(--gold)] text-black px-2 py-2 rounded-full">
        <?php echo e($blog->author); ?>

      </span>
    </div>

    <a href="<?php echo e($href); ?>">
      <div class="text-xl border border-black px-2 py-1 rounded-full
                  hover:bg-[color:var(--green)] hover:text-white hover:scale-110
                  transition-transform duration-300 ease-in-out">
        <i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i>
      </div>
    </a>
  </div>
</div>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\post-thumbnail-two.blade.php ENDPATH**/ ?>