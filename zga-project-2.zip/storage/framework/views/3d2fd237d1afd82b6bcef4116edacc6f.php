<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'content',
    'active' => false // default collapsed
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'content',
    'active' => false // default collapsed
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white rounded-xl border overflow-hidden shadow-sm" x-data="{ expanded: <?php echo e($active ? 'true' : 'false'); ?> }">
  <button
    @click="expanded = !expanded"
    class="w-full px-6 py-4 flex justify-between items-center font-semibold text-left hover:bg-[color:var(--gold)] ease-in-out duration-300"
>
    <span><?php echo e($title); ?></span>
    <span class="bg-[color:var(--green)] rounded-full w-6 h-6 flex items-center justify-center text-white text-xs transition ease-in-out duration-150"
          :class="{ 'rotate-180': expanded }">
      <i class="fas fa-chevron-down"></i>
    </span>
  </button>
  <div x-show="expanded" x-collapse class="px-6 pb-4 text-sm text-gray-600 leading-relaxed transition ease-in-out duration-150'">
    <?php echo e($content); ?>

  </div>
</div>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\accordion-item.blade.php ENDPATH**/ ?>