<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="mx-10">
        <?php if (isset($component)) { $__componentOriginal85c864ed4f570ea990e8c7ea24f313a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal85c864ed4f570ea990e8c7ea24f313a3 = $attributes; } ?>
<?php $component = App\View\Components\BlogPost::resolve(['blog' => $blog] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BlogPost::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal85c864ed4f570ea990e8c7ea24f313a3)): ?>
<?php $attributes = $__attributesOriginal85c864ed4f570ea990e8c7ea24f313a3; ?>
<?php unset($__attributesOriginal85c864ed4f570ea990e8c7ea24f313a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85c864ed4f570ea990e8c7ea24f313a3)): ?>
<?php $component = $__componentOriginal85c864ed4f570ea990e8c7ea24f313a3; ?>
<?php unset($__componentOriginal85c864ed4f570ea990e8c7ea24f313a3); ?>
<?php endif; ?>
    </section>
    <section class="pre-footer">
        <div class="frame gold-bg">
            <div class="text">
                <h2>Get to know the champions</h2>
                <p>Every event is more than just a game — it's a chance to grow, to lead, and to make your mark on Zimbabwe’s golfing legacy. Join our tournaments, represent your club, and challenge yourself among the nation’s finest. The journey starts with one swing, one round, one opportunity.</p>
            </div>
            <div class="box green-bg">
                <h4>
                    CONTACT US
                </h4>
                <p>Want to make an enquiry about an event? or sign up for a tournaments do not hesitate to contact us for more details</p>
                <button class="red-gold-btn"><a href="">Learn More <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></a></button>
            </div>
        </div>
    </section>

    <section class="news-updates">
        <div class="container">
            <div class="section-title">
            <h2>What’s The Latest Updates</h2>
            <p>Stay up to date with what is happening in the world of golf in Zimbabwe</p>
            </div>

            <div class="news-updates-grid">
            <?php if($recentArticles->count()): ?>
                
                <div class="news-update-main">
                <?php if (isset($component)) { $__componentOriginal5814913d51f8413449c88292642f1258 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5814913d51f8413449c88292642f1258 = $attributes; } ?>
<?php $component = App\View\Components\PostThumbnail1::resolve(['blog' => $recentArticles[0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('post-thumbnail1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PostThumbnail1::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('blog.show', $recentArticles[0]->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5814913d51f8413449c88292642f1258)): ?>
<?php $attributes = $__attributesOriginal5814913d51f8413449c88292642f1258; ?>
<?php unset($__attributesOriginal5814913d51f8413449c88292642f1258); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5814913d51f8413449c88292642f1258)): ?>
<?php $component = $__componentOriginal5814913d51f8413449c88292642f1258; ?>
<?php unset($__componentOriginal5814913d51f8413449c88292642f1258); ?>
<?php endif; ?>
                <div class="mt-5">
                    <a href="<?php echo e(route('blog')); ?>">
                    <button class="red-gold-btn">
                        Learn More
                        <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span>
                    </button>
                    </a>
                </div>
                </div>

                
                <?php $__currentLoopData = $recentArticles->slice(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginale11fb6f522b418983a9a50d6717c025b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale11fb6f522b418983a9a50d6717c025b = $attributes; } ?>
<?php $component = App\View\Components\PostThumbnailTwo::resolve(['blog' => $article] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('post-thumbnail-two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PostThumbnailTwo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('blog.show', $article->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale11fb6f522b418983a9a50d6717c025b)): ?>
<?php $attributes = $__attributesOriginale11fb6f522b418983a9a50d6717c025b; ?>
<?php unset($__attributesOriginale11fb6f522b418983a9a50d6717c025b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale11fb6f522b418983a9a50d6717c025b)): ?>
<?php $component = $__componentOriginale11fb6f522b418983a9a50d6717c025b; ?>
<?php unset($__componentOriginale11fb6f522b418983a9a50d6717c025b); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No recent articles available.</p>
            <?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\blog\show.blade.php ENDPATH**/ ?>