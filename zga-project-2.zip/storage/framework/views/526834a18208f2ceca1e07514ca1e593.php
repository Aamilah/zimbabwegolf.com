<?php if($paginator->hasPages()): ?>
    <nav aria-label="Page navigation example">
        <?php if($paginator->hasPages()): ?>
    <nav class="flex justify-center my-1">
        <ul class="flex flex-wrap items-center gap-2 text-sm">
            
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <span class="w-10 h-10 text-sm text-white bg-black rounded-full flex items-center justify-center cursor-not-allowed"><i class="fa-solid fa-arrow-left"></i></span>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="w-10 h-10 bg-[color:var(--red)] text-white rounded-full flex items-center justify-center hover:bg-red-700 transition">
                        <i class="fa-solid fa-arrow-left text-sm"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li>
                        <span class="px-4 py-2 text-sm text-gray-400"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <span class="w-10 h-10 bg-[color:var(--gold)] text-white rounded-full flex items-center justify-center">
                                    <?php echo e($page); ?>

                                </span>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e($url); ?>" class="w-10 h-10 bg-[color:var(--green)] text-white rounded-full flex items-center justify-center hover:bg-green-700 transition">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="w-10 h-10 bg-[color:var(--red)] text-white rounded-full flex items-center justify-center text-sm hover:bg-red-700 transition">
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </li>
            <?php else: ?>
                <li>
                    <span class="w-10 h-10 text-sm text-white bg-black rounded-full flex items-center justify-center cursor-not-allowed"><i class="fa-solid fa-arrow-right"></i></span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\vendor\pagination\main.blade.php ENDPATH**/ ?>