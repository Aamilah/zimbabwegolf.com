<p><strong>Name:</strong> <?php echo e($formData['name']); ?></p>
<p><strong>Email:</strong> <?php echo e($formData['email']); ?></p>
<p><strong>Subject:</strong> <?php echo e($formData['subject']); ?></p>
<p><strong>Message:</strong><br><?php echo e($formData['message']); ?></p>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\emails\contact-form.blade.php ENDPATH**/ ?>