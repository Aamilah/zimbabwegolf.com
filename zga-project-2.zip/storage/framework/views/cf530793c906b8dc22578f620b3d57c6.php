<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Scores Overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Scores Overview')]); ?>
<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    <div class="link-grid">
        <div class="col-span-2">
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">Review Scores</div>
                    <div class="text-2xl font-semibold">See All Your Scores</div>
                    <a href="#leaderboard-table">
                        <div class="grid-link-btn">Explore More</div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-plus-circle text-xl"></i>
                </div>
            </div>
        </div>
        <div class="col-span-2">
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">See Ranking</div>
                    <div class="text-2xl font-semibold">Check Out Current Leaderboard</div>
                    <a href="#leaderboard-table">
                        <div class="grid-link-btn">Explore More</div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-eye text-xl"></i>
                </div>
            </div>
        </div>
    </div>
    <div id="leaderboard-table">
        <?php if (isset($component)) { $__componentOriginald842fdbf9c6d158edd3f9502336d4931 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald842fdbf9c6d158edd3f9502336d4931 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-bg-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-bg-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="table-wrapper">
                <table class="admin-table searchable-table">
                    <thead>
                        <tr>
                            <th>Tournament</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Venue</th>
                            <th>Rounds</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tournamentPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournamentPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($tournamentPlayer->tournament_title); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($tournamentPlayer->start_date)->format('d M Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($tournamentPlayer->end_date)->format('d M Y')); ?></td>
                                <td><?php echo e(optional($tournamentPlayer->courseDetail)->name); ?></td>
                                <td><?php echo e($tournamentPlayer->rounds); ?></td>
                                <td>
                                    <?php if(\Carbon\Carbon::parse($tournamentPlayer->start_date)->isFuture()): ?>
                                        <span class="inline-block bg-blue-100 text-blue-600 text-xs px-2 py-1 rounded-full">Upcoming</span>
                                    <?php elseif(\Carbon\Carbon::parse($tournamentPlayer->end_date)->isPast()): ?>
                                        <span class="inline-block bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full">Completed</span>
                                    <?php else: ?>
                                        <span class="inline-block bg-red-100 text-red-600 text-xs px-2 py-1 rounded-full">Ongoing</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.leaderboard.show', $tournamentPlayer->id)); ?>" class="w-10 h-10 bg-[#68d362] text-white rounded-full flex items-center justify-center">
                                    <i class="text-sm fa-solid fa-medal"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">No tournaments with players found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="mt-4">
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald842fdbf9c6d158edd3f9502336d4931)): ?>
<?php $attributes = $__attributesOriginald842fdbf9c6d158edd3f9502336d4931; ?>
<?php unset($__attributesOriginald842fdbf9c6d158edd3f9502336d4931); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald842fdbf9c6d158edd3f9502336d4931)): ?>
<?php $component = $__componentOriginald842fdbf9c6d158edd3f9502336d4931; ?>
<?php unset($__componentOriginald842fdbf9c6d158edd3f9502336d4931); ?>
<?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\leaderboard\index.blade.php ENDPATH**/ ?>