<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'weight', 'style', 'path']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'weight', 'style', 'path']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

@font-face {
  font-display: swap;
  font-family: '<?php echo e($name); ?>';
  font-style: <?php echo e($style); ?>;
  font-weight: <?php echo e($weight); ?>;
  src: url('<?php echo e($path); ?>') format('woff2');
}
<?php /**PATH C:\Users\user\Herd\zga_project\vendor\log1x\laravel-webfonts\resources\views\font-face.blade.php ENDPATH**/ ?>