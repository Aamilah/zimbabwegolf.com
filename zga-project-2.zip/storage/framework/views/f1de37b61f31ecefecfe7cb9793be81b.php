<div class="tournament-card">
    <div class="tournament-card-header">
        <h3><?php echo e($tournament->tournament_title); ?></h3>
        <div class="tournament-tag">
            <p><?php echo e($tournament->presenter); ?></p>
        </div>
    </div>

    <div class="tournament-card-body">
        <div class="tournament-card-detail">
            <div class="tournament-card-icon gold-bg">
                <img src="<?php echo e(asset('icons/location.png')); ?>" alt="location icon">
            </div>
            <div class="tournament-card-text">
                <p><?php echo e($tournament->courseDetail->name); ?></p>
            </div>
        </div>

        <div class="tournament-card-detail">
            <div class="tournament-card-icon green-bg">
                <img src="<?php echo e(asset('icons/map-icon.png')); ?>" alt="map icon">
            </div>
            <div class="tournament-card-text">
                <p><?php echo e($tournament->location_code ?? '—'); ?></p>
            </div>
        </div>

        <div class="tournament-card-detail">
            <div class="tournament-card-icon red-bg">
                <img src="<?php echo e(asset('icons/calender-icon.png')); ?>" alt="calendar icon">
            </div>
            <div class="tournament-card-text">
                <p><?php echo e(\Carbon\Carbon::parse($tournament->start_date)->format('d M Y')); ?> - <?php echo e(\Carbon\Carbon::parse($tournament->end_date)->format('d M Y')); ?></p>
            </div>
        </div>

        <div class="tournament-card-detail">
            <div class="tournament-card-icon black-bg">
                <img src="<?php echo e(asset('icons/warning-icon.png')); ?>" alt="warning icon">
            </div>
            <div class="tournament-card-text">
                <p>Entries Close On: <?php echo e(\Carbon\Carbon::parse($tournament->entries_close)->format('d M Y')); ?></p>
            </div>
        </div>

        
        <table class="custom-table">
            <tbody>
                <tr>
                    <td rowspan="2">Ladies</td>
                    <td>Championship</td>
                    <td>54 Holes : <?php echo e($tournament->ladies_champ_handicap); ?></td>
                    <td>$<?php echo e($tournament->ladies_champ_fee); ?></td>
                </tr>
                <tr>
                    <td>Net</td>
                    <td>36 Holes : <?php echo e($tournament->ladies_net_handicap); ?></td>
                    <td>$<?php echo e($tournament->ladies_net_fee); ?></td>
                </tr>
                <tr>
                    <td rowspan="2">Men</td>
                    <td>Championship</td>
                    <td>54 Holes : <?php echo e($tournament->men_champ_handicap); ?></td>
                    <td>$<?php echo e($tournament->men_champ_fee); ?></td>
                </tr>
                <tr>
                    <td>Net</td>
                    <td>36 Holes : <?php echo e($tournament->men_net_handicap); ?></td>
                    <td>$<?php echo e($tournament->men_net_fee); ?></td>
                </tr>
            </tbody>
        </table>

        <div class="tournament-tag--gold">
            <p>Contact Us: <?php echo e($tournament->contact_email ?? 'admin@zga.org.zw'); ?></p>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\tournament-card.blade.php ENDPATH**/ ?>