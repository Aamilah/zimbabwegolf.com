<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Edit Tournament']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Edit Tournament')]); ?>
    <div>
        <div class="z-50 absolute right-16 flex flex-row gap-2">
            <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div> 
        <div class="inverted-radius relative" id="tournamentsSection">
            <div class="inverted-radius-content">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <div class="frame-dot green-bg"></div>
                    <div class="frame-dot gold-bg"></div>
                    <div class="frame-dot red-bg"></div>
                </div>
                <div class="frame-wrapper">
                    <form action="<?php echo e(route('admin.tournaments.update', $tournament->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label class="block font-medium text-sm">Title</label>
                            <input type="text" name="tournament_title" value="<?php echo e(old('tournament_title', $tournament->tournament_title)); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="block font-medium text-sm">Presenter</label>
                            <input type="text" name="presenter" value="<?php echo e(old('presenter', $tournament->presenter)); ?>" class="form-input">
                        </div>
                        <div>
                            <label for="course_detail_id" class="form-label">Venue</label>
                            <select name="course_detail_id" id="course_detail_id" class="form-input" required>
                            <option value="">Select Venue</option>
                            <?php $__currentLoopData = $course_details_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_detail_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course_detail_id->id); ?>" <?php echo e(old('course_detail_id', $tournament->course_detail_id) == $course_detail_id->id ? 'selected' : ''); ?>>
                                <?php echo e($course_detail_id->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Location Code</label>
                            <input type="text" name="location_code" value="<?php echo e(old('venue', $tournament->location_code)); ?>" class="form-input">
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block font-medium text-sm">Start Date</label>
                                <input type="date" name="start_date" value="<?php echo e(old('start_date', $tournament->start_date)); ?>" class="w-full rounded border p-2">
                            </div>
                            <div>
                                <label class="block font-medium text-sm">End Date</label>
                                <input type="date" name="end_date" value="<?php echo e(old('end_date', $tournament->end_date)); ?>" class="w-full rounded border p-2">
                            </div>
                        </div>
                        <div>
                            <label class="block font-medium text-sm">Entries Close</label>
                            <input type="date" name="entries_close" value="<?php echo e(old('entries_close', $tournament->entries_close)); ?>" class="w-full rounded border p-2">
                        </div>
                        <div>
                            <label class="form-label">Number of Rounds</label>
                            <input type="number" name="rounds" min="1" class="form-input" placeholder="e.g. 2" value="<?php echo e(old('rounds', $tournament->rounds)); ?>" required>
                        </div>
                        <h4 class="my-4 text-xs">Ladies Categories</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="form_label">Championship Handicap Range</label>
                                <input type="text" name="ladies_champ_handicap" value="<?php echo e(old('ladies_champ_handicap', $tournament->ladies_champ_handicap)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Championship Fee</label>
                                <input type="number" name="ladies_champ_fee" value="<?php echo e(old('ladies_champ_fee', $tournament->ladies_champ_fee)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Net Handicap Range</label>
                                <input type="text" name="ladies_net_handicap" value="<?php echo e(old('ladies_net_handicap', $tournament->ladies_net_handicap)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Net Fee</label>
                                <input type="number" name="ladies_net_fee" value="<?php echo e(old('ladies_net_fee', $tournament->ladies_net_fee)); ?>" class="form-input">
                            </div>
                        </div>
                        <h4 class="my-4 text-xs">Mens Categories</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="form_label">Championship Handicap Range</label>
                                <input type="text" name="mens_champ_handicap" value="<?php echo e(old('men_champ_handicap', $tournament->men_champ_handicap)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Championship Fee</label>
                                <input type="number" name="men_champ_fee" value="<?php echo e(old('men_champ_fee', $tournament->men_champ_fee)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Net Handicap Range</label>
                                <input type="text" name="men_net_handicap" value="<?php echo e(old('men_net_handicap', $tournament->men_net_handicap)); ?>" class="form-input">
                            </div>
                            <div>
                                <label class="form_label">Net Fee</label>
                                <input type="number" name="men_net_fee" value="<?php echo e(old('men_net_fee', $tournament->men_net_fee)); ?>" class="form-input">
                            </div>
                        </div>
        
                        <div class="my-4"><button class="green-red-btn">Update Tournament <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\tournaments\edit.blade.php ENDPATH**/ ?>