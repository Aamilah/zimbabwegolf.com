<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Add A Course Hole Details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Add A Course Hole Details')]); ?>
    <div class="p-4">
        <?php if (isset($component)) { $__componentOriginal3720980d10c794fab505e92af7bcadba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3720980d10c794fab505e92af7bcadba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.file-section-bg','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('file-section-bg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form action="<?php echo e(route('admin.course-details.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                    <?php if($errors->any()): ?>
                        <ul class="px-4 py-2 bg-red-100 rounded mb-4">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="my-2 text-red-500"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="mb-4">
                        <label for="name" class="form-label">Name <span class="text-red-500">*</span></label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required class="form-input w-full" />
                    </div>

                    <div class="mb-4">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" name="location" id="location" value="<?php echo e(old('location')); ?>" class="form-input w-full" />
                    </div>

                    <div class="mb-4">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" id="description" rows="3" class="form-input w-full"><?php echo e(old('description')); ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label for="par" class="form-label">Par</label>
                        <input type="number" name="par" id="par" value="<?php echo e(old('par')); ?>" class="form-input" min="1" />
                    </div>

                    <div class="mb-4">
                        <label for="total_yardage" class="form-label">Total Yardage</label>
                        <input type="number" name="total_yardage" id="total_yardage" value="<?php echo e(old('total_yardage')); ?>" class="form-input" min="0" />
                    </div>

                    <div class="my-4">
                        <button class="green-red-btn">
                            Add Course <span><i class="fa-solid fa-plus"></i></span>
                        </button>
                    </div>

                </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3720980d10c794fab505e92af7bcadba)): ?>
<?php $attributes = $__attributesOriginal3720980d10c794fab505e92af7bcadba; ?>
<?php unset($__attributesOriginal3720980d10c794fab505e92af7bcadba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3720980d10c794fab505e92af7bcadba)): ?>
<?php $component = $__componentOriginal3720980d10c794fab505e92af7bcadba; ?>
<?php unset($__componentOriginal3720980d10c794fab505e92af7bcadba); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\course-details\create.blade.php ENDPATH**/ ?>