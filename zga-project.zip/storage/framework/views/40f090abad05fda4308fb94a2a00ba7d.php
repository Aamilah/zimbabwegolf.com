<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Player Details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Player Details')]); ?>
<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<div>
    <div class="z-50 absolute right-16 flex flex-row gap-2">
        <a href="<?php echo e(route('admin.course-details.edit', $courseDetail->id)); ?>">
            <button class="inverted-corner-btn w-10 h-10 items-center justify-center">
                <i class="fa-solid fa-clipboard"></i>
            </button>
        </a>
        <form action="<?php echo e(route('admin.course-details.destroy', $courseDetail->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete all the details for this course?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
            <button type="submit" class="trash-btn inverted-corner-btn w-10 h-10  rounded-full flex items-center justify-center">
                <i class="text-sm fa-solid fa-trash"></i>
            </button>
        </form>
        <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
    </div> 
    <div class="inverted-radius my-5 relative">
        <div class="inverted-radius-content">
            <div class="flex flex-wrap items-center gap-2 mb-4">
                <div class="filter-tab">Golf Course Details</div>
            </div>
            <div class="table-wrapper">
                <table class="admin-table searchable-table">
                    <tbody>
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($courseDetail->name); ?></td>
                        </tr>
                        <tr>
                            <th>Location</th>
                            <td><?php echo e($courseDetail->location); ?></td>
                        </tr>
                        <tr>
                            <th>Description</th>
                            <td><?php echo e($courseDetail->description); ?></td>
                        </tr>
                        <tr>
                            <th>Par</th>
                            <td><?php echo e($courseDetail->par); ?></td>
                        </tr>
                        <tr>
                            <th>Total Yardage</th>
                            <td><?php echo e($courseDetail->total_yardage); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="z-50 absolute right-16 flex flex-row gap-2">
        <a href="<?php echo e(route('admin.course-holes.edit', $courseDetail->id)); ?>">
            <button class="inverted-corner-btn w-10 h-10 items-center justify-center">
                <i class="fa-solid fa-clipboard"></i>
            </button>
        </a>
        <form action="<?php echo e(route('admin.course-holes.destroy', $courseDetail->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete these hole details?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
            <button type="submit" class="trash-btn inverted-corner-btn w-10 h-10  rounded-full flex items-center justify-center">
                <i class="text-sm fa-solid fa-trash"></i>
            </button>
        </form>
        <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
    </div> 
    <div class="inverted-radius my-5 relative">
        <div class="inverted-radius-content">
            <div class="flex flex-wrap items-center gap-2 mb-4">
                <div class="filter-tab">Hole Details</div>
            </div>
            <?php
                $holes = $courseDetail->holes()->orderBy('hole_number')->get();

                $inPar = $holes->where('hole_number', '<=', 9)->sum('par');
                $outPar = $holes->where('hole_number', '>', 9)->sum('par');
                $totalPar = $holes->sum('par');

                $inYardage = $holes->where('hole_number', '<=', 9)->sum('yardage');
                $outYardage = $holes->where('hole_number', '>', 9)->sum('yardage');
                $totalYardage = $holes->sum('yardage');
            ?>

            <div class="table-wrapper overflow-x-auto">
                <table class="admin-table searchable-table text-center">
                    <thead>
                        <tr>
                            <th>Hole</th>
                            <?php $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($hole->hole_number == 9): ?>
                                    <th><?php echo e($hole->hole_number); ?></th>
                                    <th>In</th> <!-- After Hole 9 -->
                                <?php elseif($hole->hole_number == 18): ?>
                                    <th><?php echo e($hole->hole_number); ?></th>
                                    <th>Out</th> <!-- After Hole 18 -->
                                    <th>Total</th> <!-- Final total -->
                                <?php else: ?>
                                    <th><?php echo e($hole->hole_number); ?></th>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Par</td>
                            <?php $__empty_1 = true; $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($hole->hole_number == 9): ?>
                                    <th><?php echo e($hole->par); ?></th>
                                    <td><?php echo e($inPar); ?></td>
                                <?php elseif($hole->hole_number == 18): ?>
                                    <th><?php echo e($hole->par); ?></th>
                                    <td><?php echo e($outPar); ?></td>
                                    <td><?php echo e($totalPar); ?></td>
                                <?php else: ?>
                                    <th><?php echo e($hole->par); ?></th>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td colspan="99">No hole details available for this course.</td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td>Yardage</td>
                            <?php $__empty_1 = true; $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($hole->hole_number == 9): ?>
                                    <th><?php echo e($hole->yardage); ?></th>
                                    <td><?php echo e($inYardage); ?></td>
                                <?php elseif($hole->hole_number == 18): ?>
                                    <th><?php echo e($hole->yardage); ?></th>
                                    <td><?php echo e($outYardage); ?></td>
                                    <td><?php echo e($totalYardage); ?></td>
                                <?php else: ?>
                                    <th><?php echo e($hole->yardage); ?></th>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\course-details\show.blade.php ENDPATH**/ ?>