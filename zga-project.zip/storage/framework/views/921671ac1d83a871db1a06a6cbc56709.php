<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['blog', 'href' => '#']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['blog', 'href' => '#']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="news-carousel-item">
      <div class="news-carousel-grid">
            <div class="news-carousel-slice">
                <div class="hero-content">
                    <div class="hero-text">
                        <h1><?php echo e($post->headline); ?></h1>
                        <p><?php echo e(\Illuminate\Support\Str::limit(strip_tags($post->content), 250, '...')); ?></p>
                    </div>
                    <a href="<?php echo e($href); ?>">
                        <div class="hero-button">
                            <button class="red-gold-btn">Learn More <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></button>
                        </div>
                    </a>
                    <div class="hero-tags">
                        <div class="hero-tag-row">
                            <div class="hero-tag-icon">
                                <img src="<?php echo e(asset('icons/golf_ball_tee.png')); ?>" alt="golf ball tee icon">
                            </div>
                            <?php
                                $created = \Carbon\Carbon::parse($post->created_at);
                            ?>
                            <div class="hero-tag green-bg">
                                <p>Zimbabwe Golf Association</p>
                            </div>
                            <div class="hero-tag gold-bg">
                                <p><?php echo e($post->author); ?></p>
                            </div>
                        </div>
                        <div class="hero-tag-row">
                            <div class="hero-tag red-bg">
                                <p><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d M, Y')); ?></p>
                            </div>
                            <div class="hero-tag black-bg">
                                <p><?php echo e($post->category); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="news-carousel-slice frame">
                <img src="<?php echo e(asset('storage/' . $post->thumbnail)); ?>" alt="<?php echo e($post->image_caption); ?>">  
            </div>
      </div>
    </div><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\news-carousel-item.blade.php ENDPATH**/ ?>