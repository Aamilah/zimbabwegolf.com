<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Create A Blog Post']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Create A Blog Post')]); ?>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-lite.min.js"></script>
    <div>
        <div class="inverted-radius my-5 relative">
            <div class="inverted-radius-content">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <div class="frame-dot green-bg"></div>
                    <div class="frame-dot gold-bg"></div>
                    <div class="frame-dot red-bg"></div>
                </div>
                <div class="frame-wrapper">
                <form action="<?php echo e(route('admin.blog.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->any()): ?>
                        <ul class="px-4 py-2 bg-red-100 rounded mb-4">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="my-2 text-red-500"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                    <div class="mb-4">
                        <label class="form-label">Headline</label>
                        <input type="text" name="headline" class="form-input" value="<?php echo e(old('headline')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Category</label>
                        <input type="text" name="category" class="form-input" value="<?php echo e(old('category')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Author</label>
                        <input type="text" name="author" class="form-input" value="<?php echo e(old('author')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Author ID</label>
                        <input type="text" name="author_id" class="form-input" value="<?php echo e(old('author_id')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label for="thumbnail" class="block text-sm font-medium text-gray-700 mb-1">Thumbnail Image</label>
                        <input
                            type="file"
                            name="thumbnail"
                            accept="image/*"
                            id="thumbnail"
                            class="form-input
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-[200px] file:border-0
                                file:text-sm file:font-semibold
                                file:bg-green-500 file:text-white
                                hover:file:bg-green-700
                                focus:outline-none focus:ring focus:border-green"
                        >
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Image Caption</label>
                        <input type="text" name="image_caption" class="form-input" value="<?php echo e(old('image_caption')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Image Credit</label>
                        <input type="text" name="image_credit" class="form-input" value="<?php echo e(old('image_credit')); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Content</label>
                        <textarea id="summernote" name="content" class="form-input"><?php echo old('content'); ?></textarea>
                    </div>

                    <div class="my-4">
                        <button class="green-red-btn">
                            Post Article <span><i class="fa-solid fa-plus"></i></span>
                        </button>
                    </div>
                </form>

                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
                $('#summernote').summernote({
                    placeholder: 'Write your blog post...',
                    tabsize: 2,
                    height: 300,
                    toolbar: [
                        ['style', ['style']],
                        ['font', ['bold', 'underline', 'clear']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['view', ['fullscreen', 'codeview', 'help']]
                    ]
                });
            });

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\blog\create.blade.php ENDPATH**/ ?>