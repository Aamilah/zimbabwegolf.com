<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $user = Auth::user();
?>

<?php if($user && $user->department === 'staff'): ?>
    <?php if (isset($component)) { $__componentOriginal21baf83cca9536a0054e5dafc5afc171 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21baf83cca9536a0054e5dafc5afc171 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php echo e($slot); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21baf83cca9536a0054e5dafc5afc171)): ?>
<?php $attributes = $__attributesOriginal21baf83cca9536a0054e5dafc5afc171; ?>
<?php unset($__attributesOriginal21baf83cca9536a0054e5dafc5afc171); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21baf83cca9536a0054e5dafc5afc171)): ?>
<?php $component = $__componentOriginal21baf83cca9536a0054e5dafc5afc171; ?>
<?php unset($__componentOriginal21baf83cca9536a0054e5dafc5afc171); ?>
<?php endif; ?>
<?php elseif($user && $user->department === 'player'): ?>
    <?php if (isset($component)) { $__componentOriginal3be17683fa491539cec6e5dd61e04fcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3be17683fa491539cec6e5dd61e04fcc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.player-admin-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('player-admin-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php echo e($slot); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3be17683fa491539cec6e5dd61e04fcc)): ?>
<?php $attributes = $__attributesOriginal3be17683fa491539cec6e5dd61e04fcc; ?>
<?php unset($__attributesOriginal3be17683fa491539cec6e5dd61e04fcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3be17683fa491539cec6e5dd61e04fcc)): ?>
<?php $component = $__componentOriginal3be17683fa491539cec6e5dd61e04fcc; ?>
<?php unset($__componentOriginal3be17683fa491539cec6e5dd61e04fcc); ?>
<?php endif; ?>
<?php elseif($user && $user->department === 'tournament_official'): ?>
    <?php if (isset($component)) { $__componentOriginal8fd613bfc5855bb41a66dc49d0523081 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fd613bfc5855bb41a66dc49d0523081 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tournament-official-admin-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tournament-official-admin-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php echo e($slot); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fd613bfc5855bb41a66dc49d0523081)): ?>
<?php $attributes = $__attributesOriginal8fd613bfc5855bb41a66dc49d0523081; ?>
<?php unset($__attributesOriginal8fd613bfc5855bb41a66dc49d0523081); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fd613bfc5855bb41a66dc49d0523081)): ?>
<?php $component = $__componentOriginal8fd613bfc5855bb41a66dc49d0523081; ?>
<?php unset($__componentOriginal8fd613bfc5855bb41a66dc49d0523081); ?>
<?php endif; ?>
<?php else: ?>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php echo e($slot); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php endif; ?>


<div class="text-lg font-semibold text-gray-700">
    <?php echo e($title); ?>

</div>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\admin.blade.php ENDPATH**/ ?>