<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Add Scores']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Add Scores')]); ?>
    <div>
        <div class="z-50 absolute right-16 flex flex-row gap-2">
            <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>
        <div class="inverted-radius my-5 relative">
            <div class="inverted-radius-content">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <div class="frame-dot green-bg"></div>
                    <div class="frame-dot gold-bg"></div>
                    <div class="frame-dot red-bg"></div>
                </div>
            <div class="frame-wrapper">
                <form action="<?php echo e(route('admin.scoreboard-requests.store', $tournament->id)); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <ul class="px-4 py-2 bg-red-100">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="my-2 text-red-500"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="mb-4">
                        <label class="form-label">Tournament</label>
                        <input
                            type="text"
                            class="form-input bg-gray-100 cursor-not-allowed"
                            value="<?php echo e($tournament->tournament_title); ?>"
                            disabled
                        >
                        <input
                            type="hidden"
                            name="tournament_id"
                            value="<?php echo e($tournament->id); ?>"
                        >
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Player Name</label>
                        <input
                            type="text"
                            class="form-input bg-gray-100 cursor-not-allowed"
                            value="<?php echo e(Auth::user()->name); ?>"
                            disabled
                        >
                        <input type="hidden" name="tournament_player_id" value="<?php echo e($tournamentPlayer->id); ?>">
                    </div>
                    <div class="table-wrapper">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Hole</th>
                                    <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th>Round <?php echo e($round); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $holeNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($hole); ?></td>
                                        <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $existingScore = $existingScores[$round][$hole] ?? null;
                                                $existingPar = $existingScore->par ?? null;
                                                $isApproved = $existingScore && $existingScore->approved;
                                            ?>
                                            <td>
                                                <input type="hidden" name="holes[<?php echo e($hole); ?>][<?php echo e($round); ?>][hole_number]" value="<?php echo e($hole); ?>">
                                                <input type="hidden" name="holes[<?php echo e($hole); ?>][<?php echo e($round); ?>][round_number]" value="<?php echo e($round); ?>">
                                                <input
                                                    type="number"
                                                    name="holes[<?php echo e($hole); ?>][<?php echo e($round); ?>][par]"
                                                    class="w-60 text-center border rounded py-2 <?php echo e($isApproved ? 'bg-gray-200 cursor-not-allowed' : ''); ?>"
                                                    value="<?php echo e(old("holes.$hole.$round.par", $existingPar)); ?>"
                                                    placeholder="Leave empty if not played"
                                                    <?php if($isApproved): ?> disabled <?php endif; ?>
                                                >
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="my-4"><button class="green-red-btn">Submit Scoreboard Request <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></button></div>
                </form>
            </div>
        </div>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const inputs = Array.from(document.querySelectorAll('input[type="number"]'));

        inputs.forEach((input, index) => {
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();

                    // Focus next input if it exists
                    const nextInput = inputs[index + 1];
                    if (nextInput) {
                        nextInput.focus();
                    }
                }
            });
        });
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\scoreboard_requests\create.blade.php ENDPATH**/ ?>