    <div class="h-16 flex items-center justify-start px-4 mt-10 bg-white rounded-2xl ml-5">
      <img src="<?php echo e(asset('images/logo/zga_logo.jpg')); ?>" alt="ZGA Logo" class="h-12" />
      <span class="font-semibold text-sm">Zimbabwe Golf Association</span>
    </div>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\application-logo.blade.php ENDPATH**/ ?>