<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    <div class="grid grid-cols-4 gap-4">
        <div>
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">Manage Tee Times</div>
                    <div class="text-2xl font-semibold">Assign Tee Times</div>
                    <a href="<?php echo e(route('admin.tee-assignments.index')); ?>">
                        <div class="grid-link-btn">
                            Explore More
                        </div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-clock text-xl"></i>
                </div>
            </div>
        </div>
        <div>
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">Manage Scores</div>
                    <div class="text-2xl font-semibold">Approve Tournaments Scores</div>
                    <a href="<?php echo e(route('admin.scoreboard-requests.index')); ?>">
                        <div class="grid-link-btn">Explore More</div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-check text-xl"></i>
                </div>
            </div>
        </div>
        <div>
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">View Tournaments</div>
                    <div class="text-2xl font-semibold">Track Upcoming Tournaments</div>
                    <a href="<?php echo e(route('admin.tournaments.index')); ?>">
                        <div class="grid-link-btn">Explore More</div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-calender text-xl"></i>
                </div>
            </div>
        </div>
        <div>
            <div class="link-grid-item">
                <div>
                    <div class="text-sm">View Course Details</div>
                    <div class="text-2xl font-semibold">Update Course Information</div>
                    <a href="<?php echo e(route('admin.course-details.index')); ?>">
                        <div class="grid-link-btn">Explore More</div>
                    </a>
                </div>
                <div class="link-grid-icon">
                    <i class="fas fa-flag text-xl"></i>
                </div>
            </div>
        </div>
        <div class="col-span-3 row-span-2">
            <div>
                <div class="z-50 absolute right-[350px] flex flex-row gap-2">
                    <a href="<?php echo e(route('admin.leaderboard.show', $tournament->id)); ?>">
                        <button class="inverted-corner-btn"> Leaderboard
                        <i class="ml-10 fa-solid fa-newspaper"></i>
                        </button>
                    </a>
                </div>
                <div class="inverted-radius">
                    <div class="inverted-radius-content">
                        <div class="flex flex-wrap items-center gap-2 mb-4">
                            <div class="frame-dot green-bg"></div>
                            <div class="frame-dot gold-bg"></div>
                            <div class="frame-dot red-bg"></div>
                        </div>
                        <div class="table-wrapper">
                            <table class="dashboard-table">
                                <thead>
                                    <tr>
                                        <th>Country</th>
                                        <th>Name</th>
                                        <th>Hole</th>
                                        <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th>R<?php echo e($round); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th>Par</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tournamentPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $playerId = $player->id;
                                            $roundPar = $courseHoles->sum('par');
                                            $finalTotal = collect($totals[$playerId] ?? [])->sum();
                                            $expectedTotal = $roundPar * count($rounds);
                                            $finalVsPar = $finalTotal - $expectedTotal;
                                        ?>
                                        <tr class="cursor-pointer transition hover:bg-gray-100"
                                            onclick="toggleDetails(<?php echo e($playerId); ?>)"
                                            style="user-select:none;">
                                            <td><?php echo e($player->country); ?></td>
                                            <td><?php echo e($player->name); ?></td>
                                            <?php if(isset($latestProgress[$player->id]) && $latestProgress[$player->id]['round']): ?>
                                                <td><?php echo e($latestProgress[$player->id]['hole']); ?></td>
                                            <?php else: ?>
                                                <td>-</td>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $score = $totals[$playerId][$round] ?? null;
                                                    $roundVsPar = $score !== null ? $score - $roundPar : null;
                                                ?>
                                                <td>
                                                    <?php echo e($score ?? '-'); ?>

                                                    <div class="text-xs font-semibold
                                                        <?php echo e($roundVsPar < 0 ? 'text-green-600' : ($roundVsPar > 0 ? 'text-red-600' : 'text-gray-700')); ?>">
                                                        <?php if($roundVsPar === null): ?>
                                                            &nbsp;
                                                        <?php elseif($roundVsPar == 0): ?>
                                                            E
                                                        <?php elseif($roundVsPar > 0): ?>
                                                            +<?php echo e($roundVsPar); ?>

                                                        <?php else: ?>
                                                            <?php echo e($roundVsPar); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $currentPar = ($latestProgress[$player->id]['round'] && $latestProgress[$player->id]['round'] < count($rounds))
                                                    ? $roundPar * $latestProgress[$player->id]['round']
                                                    : $roundPar * count($rounds);
                                                $scoreSoFar = collect($totals[$playerId] ?? [])->take($latestProgress[$player->id]['round'])->sum();
                                                $parDiff = $scoreSoFar - $currentPar;
                                            ?>
                                            <td class="<?php echo e($parDiff < 0 ? 'text-green-600' : ($parDiff > 0 ? 'text-red-600' : 'text-gray-700')); ?>">
                                                    <?php if($parDiff == 0): ?>
                                                        E
                                                    <?php elseif($parDiff > 0): ?>
                                                        +<?php echo e($parDiff); ?>

                                                    <?php else: ?>
                                                        <?php echo e($parDiff); ?>

                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="font-bold">
                                                <?php echo e($finalTotal ?: '-'); ?>

                                                <div class="text-xs font-semibold
                                                    <?php echo e($finalVsPar < 0 ? 'text-green-600' : ($finalVsPar > 0 ? 'text-red-600' : 'text-gray-700')); ?>">
                                                    <?php if($finalVsPar == 0): ?>
                                                        E
                                                    <?php elseif($finalVsPar > 0): ?>
                                                        +<?php echo e($finalVsPar); ?>

                                                    <?php else: ?>
                                                        <?php echo e($finalVsPar); ?>

                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr id="details-<?php echo e($playerId); ?>" class="hidden bg-white">
                                            <td colspan="<?php echo e(4 + count($rounds) + 2); ?>">
                                                <div class="overflow-x-auto">
                                                    <table class="admin-table w-full text-center">
                                                        <thead>
                                                            <tr class="bg-gray-100 text-xs font-bold">
                                                                <th>Hole</th>
                                                                <?php $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <th><?php echo e($hole); ?></th>
                                                                    <?php if($hole == 9): ?>
                                                                        <th>In</th>
                                                                    <?php elseif($hole == 18): ?>
                                                                        <th>Out</th>
                                                                        <th>Total</th>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tr>
                                                            <tr class="bg-gray-100 text-xs font-bold">
                                                                <td>Par</td>
                                                                <?php
                                                                    $inPar = 0;
                                                                    $outPar = 0;
                                                                ?>
                                                                <?php $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $holePar = $courseHoles->firstWhere('hole_number', $hole)?->par ?? 0;
                                                                        if ($hole <= 9) $inPar += $holePar;
                                                                        else $outPar += $holePar;
                                                                    ?>
                                                                    <td><?php echo e($holePar); ?></td>
                                                                    <?php if($hole == 9): ?>
                                                                        <td class="font-bold"><?php echo e($inPar); ?></td>
                                                                    <?php elseif($hole == 18): ?>
                                                                        <td class="font-bold"><?php echo e($outPar); ?></td>
                                                                        <td class="font-bold"><?php echo e($inPar + $outPar); ?></td>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-sm">
                                                            <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $inTotal = 0;
                                                                    $outTotal = 0;
                                                                ?>
                                                                <tr>
                                                                    <td>R<?php echo e($round); ?></td>
                                                                    <?php $__currentLoopData = $holes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php
                                                                        $playerId = $player->id;
                                                                        $par = $courseHoles->firstWhere('hole_number', $hole)?->par ?? null;
                                                                        $score = isset($scores[$playerId][$round][$hole])
                                                                            ? $scores[$playerId][$round][$hole]->first()->par
                                                                            : null;
                                                                            if ($hole <= 9) $inTotal += $score;
                                                                            else $outTotal += $score;
                                                                        $scoreClass = 'round_score_bg';
                                                                        if ($score !== null && $par !== null) {
                                                                            $scoreClass .= $score == 1 ? ' hole-in-one' :
                                                                                ($score == $par - 2 ? ' eagle' :
                                                                                ($score == $par - 1 ? ' birdie' :
                                                                                ($score == $par     ? ' par' :
                                                                                ($score == $par + 1 ? ' bogey' :
                                                                                ($score == $par + 2 ? ' double_bogey' : '')))));
                                                                        }
                                                                    ?>
                                                                    <td >
                                                                        <div class="<?php echo e($scoreClass); ?>"><?php echo e($score ?? '-'); ?></div>
                                                                    </td>
                                                                        <?php if($hole == 9): ?>
                                                                            <td class="font-bold bg-gray-100"><?php echo e($inTotal); ?></td>
                                                                        <?php elseif($hole == 18): ?>
                                                                            <td class="font-bold bg-gray-100"><?php echo e($outTotal); ?></td>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <td class="font-bold bg-gray-100"><?php echo e($totals[$playerId][$round] ?? '-'); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(4 + count($rounds) + 2); ?>" class="text-center py-4">
                                                No approved scores found for this tournament.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="link-grid-item-2">
                <div class="content">
                    <div class="text-sm">Database Statistic</div>
                    <div class="text-2xl font-semibold">Total Number of Players</div>
                    <a href="<?php echo e(route('admin.blog.index')); ?>">
                        <div class="grid-link-btn">
                            Explore More
                        </div>
                    </a>
                </div>
                <div class="link-grid-number">
                    <p><?php echo e($playerCount); ?></p>
                </div>
            </div>
        </div>
        <div>
            <div class="link-grid-item-2">
                <div class="content">
                    <div class="text-sm">Database Statistic</div>
                    <div class="text-2xl font-semibold">Total Number of Tournaments</div>
                    <a href="<?php echo e(route('admin.blog.index')); ?>">
                        <div class="grid-link-btn">
                            Explore More
                        </div>
                    </a>
                </div>
                <div class="link-grid-number">
                    <p><?php echo e($tournamentCount); ?></p>
                </div>
            </div>
        </div>
        <div class="col-span-2">
            <div class="mx-5 px-5">
                <?php if($currentTournament): ?>
                    <?php if (isset($component)) { $__componentOriginala9af8b1f7f7b4750f4751ffcc49984bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9af8b1f7f7b4750f4751ffcc49984bd = $attributes; } ?>
<?php $component = App\View\Components\TournamentCard::resolve(['tournament' => $currentTournament] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tournament-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TournamentCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9af8b1f7f7b4750f4751ffcc49984bd)): ?>
<?php $attributes = $__attributesOriginala9af8b1f7f7b4750f4751ffcc49984bd; ?>
<?php unset($__attributesOriginala9af8b1f7f7b4750f4751ffcc49984bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9af8b1f7f7b4750f4751ffcc49984bd)): ?>
<?php $component = $__componentOriginala9af8b1f7f7b4750f4751ffcc49984bd; ?>
<?php unset($__componentOriginala9af8b1f7f7b4750f4751ffcc49984bd); ?>
<?php endif; ?>
                <?php else: ?>
                    <p class="text-center text-gray-500">No tournaments available.</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-span-2">
            <div>
                <div class="z-50 absolute right-16 flex flex-row gap-2">
                    <a href="<?php echo e(route('admin.tournaments.index')); ?>">
                        <button class="inverted-corner-btn"> Tournament Calendar
                        <i class="ml-10 fa-solid fa-calendar"></i>
                        </button>
                    </a>
                </div>
                <div class="inverted-radius">
                    <div class="inverted-radius-content">
                        <div class="flex flex-wrap items-center gap-2 mb-4">
                            <div class="frame-dot green-bg"></div>
                            <div class="frame-dot gold-bg"></div>
                            <div class="frame-dot red-bg"></div>
                        </div>
                        <div class="table-wrapper">
                            <table class="dashboard-table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Venue</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $upcomingTournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $today = \Carbon\Carbon::today();
                                            $start = \Carbon\Carbon::parse($tournament->start_date);
                                            $end = \Carbon\Carbon::parse($tournament->end_date);
                                            $status = $today->lt($start)
                                                ? 'Upcoming'
                                                : ($today->between($start, $end) ? 'Current' : 'Past');
                                        ?>
                                        <tr data-status="<?php echo e($status); ?>">
                                            <td><?php echo e($tournament->tournament_title); ?></td>
                                            <td><?php echo e($tournament->venue); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($tournament->start_date)->format('d M, Y')); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($tournament->end_date)->format('d M, Y')); ?></td>
                                            <td>
                                                <?php if($status === 'Upcoming'): ?>
                                                    <span class="inline-block bg-blue-100 text-blue-600 text-xs px-2 py-1 rounded-full">Upcoming</span>
                                                <?php elseif($status === 'Current'): ?>
                                                    <span class="inline-block bg-yellow-100 text-yellow-600 text-xs px-2 py-1 rounded-full">Current</span>
                                                <?php else: ?>
                                                    <span class="inline-block bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded-full">Past</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="flex gap-2 items-center justify-center">
                                                <a href="<?php echo e(route('admin.tournaments.show', $tournament->id)); ?>" class="w-7 h-7 bg-[#68d362] text-white rounded-full flex items-center justify-center">
                                                    <i class="text-[0.6rem] fa-solid fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.tournaments.edit', $tournament->id)); ?>" class="w-7 h-7 bg-[#68d362] text-white rounded-full flex items-center justify-center">
                                                    <i class="text-[0.6rem] fa-solid fa-clipboard"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.tournaments.destroy', $tournament->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this tournament?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="w-7 h-7 trash-btn rounded-full flex items-center justify-center">
                                                        <i class="text-[0.6rem] fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4">No tournaments found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\tournament-official-dashboard.blade.php ENDPATH**/ ?>