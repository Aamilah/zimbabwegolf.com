<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Edit An Article']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Edit An Article')]); ?>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-lite.min.js"></script>
    <div>
        <div class="z-50 absolute right-16 flex flex-row gap-2">
            <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>
        <div class="inverted-radius relative">
            <div class="inverted-radius-content">
                <div class="flex flex-wrap items-center gap-2 mb-4">
                    <div class="frame-dot green-bg"></div>
                    <div class="frame-dot gold-bg"></div>
                    <div class="frame-dot red-bg"></div>
                </div>
                <div class="frame-wrapper">
                    <form action="<?php echo e(route('admin.blog.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-4">
                            <label class="form-label">Headline</label>
                            <input type="text" name="headline" class="form-input" value="<?php echo e(old('headline', $blog->headline)); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Category</label>
                            <input type="text" name="category" class="form-input" value="<?php echo e(old('category', $blog->category)); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" class="form-input" value="<?php echo e(old('author', $blog->author)); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Author ID</label>
                            <input type="text" name="author_id" class="form-input" value="<?php echo e(old('author_id', $blog->author_id)); ?>" required>
                        </div>
                        <div class="my-4">
                            <label for="image_path" class="form-label">Image</label>

                            <?php
                                $image = $blog->thumbnail 
                                    ? asset('storage/' . $blog->thumbnail)
                                    : asset('images/default-player.jpg'); // <- path to your default image
                            ?>

                            <div class="mb-2">
                                <img src="<?php echo e($image); ?>" 
                                    alt="<?php echo e($blog->headline); ?>" 
                                    class="w-20 h-20 rounded-full object-cover border" />
                            </div>

                            <input
                                type="file"
                                name="image_path"
                                id="image_path"
                                accept="image/*"
                                class="form-input
                                    file:mr-4 file:py-2 file:px-4
                                    file:rounded-[200px] file:border-0
                                    file:text-sm file:font-semibold
                                    file:bg-green-500 file:text-white
                                    hover:file:bg-green-700
                                    focus:outline-none focus:ring focus:border-green"
                            >
                        </div>
                        <div class="form-group z-50">
                            <label class="form-label">Content</label>
                            <textarea id="summernote" name="content" class="form-input"><?php echo old('content', $blog->content); ?></textarea>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Image Caption</label>
                            <input type="text" name="image_caption" class="form-input" value="<?php echo e(old('image_caption', $blog->image_caption)); ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Image Credit</label>
                            <input type="text" name="image_credit" class="form-input" value="<?php echo e(old('image_credit', $blog->image_credit)); ?>" required>
                        </div>

                        <div class="my-4"><button class="green-red-btn">Update Player <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>

        <script>
        $(document).ready(function () {
                $('#summernote').summernote({
                    placeholder: 'Write your blog post...',
                    tabsize: 2,
                    height: 300,
                    toolbar: [
                        ['style', ['style']],
                        ['font', ['bold', 'underline', 'clear']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['view', ['fullscreen', 'codeview', 'help']]
                    ]
                });
            });

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\blog\edit.blade.php ENDPATH**/ ?>