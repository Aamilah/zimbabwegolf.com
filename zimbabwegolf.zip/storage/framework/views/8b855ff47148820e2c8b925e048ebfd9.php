<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Players in tournament Overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Players in tournament Overview')]); ?>
<?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'success']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    <div>
        <div class="z-50 absolute right-16 flex flex-row gap-2">
            <?php if (isset($component)) { $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $attributes = $__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__attributesOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9)): ?>
<?php $component = $__componentOriginala6e8a8c0543f8010b15f7f1df40091b9; ?>
<?php unset($__componentOriginala6e8a8c0543f8010b15f7f1df40091b9); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>
      <div class="inverted-radius my-5 relative" id="tournamentsSection">
        <div class="inverted-radius-content">
          <!-- Filter + Table Section -->
          <div class="flex flex-wrap items-center gap-2 mb-2">
            <div class="bg-green-600 rounded-[100px] px-4 py-2 mt-2 text-white">
                <h5>Tournament: <?php echo e($tournament->tournament_title); ?></h5>
            </div>
            <div class="search-tab">
              <input type="text" placeholder="Search" class="search-input table-search" />
              <span class="search-icon"><i class="fas fa-search"></i></span>
            </div>
          </div>
          <?php
              $user = Auth::user();
          ?>

          <?php if($user && $user->department === 'tournament_official'): ?>
              <div class="flex flex-wrap items-center gap-2 mb-2">
                  <a href="<?php echo e(route('admin.tee-assignments.create', $tournament->id)); ?>"> 
                      <div class="green-bg rounded-[100px] px-4 py-1 mt-2 text-white hover:bg-green-600">
                          Assign Tee Times
                      </div>
                  </a>
              </div>
          <?php endif; ?>

          <!-- Table -->
          <div class="table-wrapper">
        <?php if($players->count()): ?>
          <table class="admin-table  searchable-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Country</th>
                <th>Player Type</th>
                <th>Gender</th>
                <th>Signed Up At</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($players->firstItem() + $index); ?></td>
                <td><?php echo e($player->name); ?></td>
                <td><?php echo e($player->country ?? '-'); ?></td>
                <td><?php echo e($player->player_type); ?></td>
                <td><?php echo e($player->gender); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($player->created_at)->format('d M, Y')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
              <tr>
                <td colspan="7">No players have signed up for this tournament yet.</td>
              </tr>
        <?php endif; ?>
            </tbody>
          </table>
          </div>
          <div class="mt-4">
              <?php echo e($players->links('vendor.pagination.adminpagination')); ?>

          </div>
        </div>
      </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\tournaments\players.blade.php ENDPATH**/ ?>