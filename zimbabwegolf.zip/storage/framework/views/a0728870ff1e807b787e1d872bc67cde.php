<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Zimbabwe Golf Association | Admin</title>

    
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicon_io/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon_io/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon_io/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('favicon_io/site.webmanifest')); ?>">

  <!-- Font Awesome Icon Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <!-- Bootstrap CSS Link -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- Main Style Link -->
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-[color:var(--green)]" x-data="{ sidebarOpen: false }">

    <?php if (isset($component)) { $__componentOriginal1179c5f19bbf2c2b959474c2b189315e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1179c5f19bbf2c2b959474c2b189315e = $attributes; } ?>
<?php $component = App\View\Components\LoadingOverlay::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading-overlay'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LoadingOverlay::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1179c5f19bbf2c2b959474c2b189315e)): ?>
<?php $attributes = $__attributesOriginal1179c5f19bbf2c2b959474c2b189315e; ?>
<?php unset($__attributesOriginal1179c5f19bbf2c2b959474c2b189315e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1179c5f19bbf2c2b959474c2b189315e)): ?>
<?php $component = $__componentOriginal1179c5f19bbf2c2b959474c2b189315e; ?>
<?php unset($__componentOriginal1179c5f19bbf2c2b959474c2b189315e); ?>
<?php endif; ?>

    <!-- Mobile top bar for sidebar toggle -->
    <div class="md:hidden flex items-center justify-between p-4 bg-white shadow">
        <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 focus:outline-none">
            <i class="fas fa-bars fa-lg"></i>
        </button>
        <span class="font-semibold text-sm">Zimbabwe Golf Association</span>
    </div>

    <!-- Sidebar -->
    <aside
        class="fixed top-0 left-0 h-screen w-64 flex flex-col z-40 bg-[color:var(--green)] transition-transform transform md:translate-x-0"
        :class="{ '-translate-x-full': !sidebarOpen }">

        <div class="h-16 flex items-center justify-start px-4 bg-white rounded-2xl m-4">
            <img src="<?php echo e(asset('images/logo/zga_logo.jpg')); ?>" alt="ZGA Logo" class="h-12" />
            <span class="font-semibold text-sm ml-2">Zimbabwe Golf Association</span>
        </div>

        <nav class="flex-1 px-4 py-6 space-y-2 overflow-y-auto">

          <a href="<?php echo e(route('admin.admin-dashboard')); ?>"
            class="admin-nav-link <?php echo e(Route::is('admin.admin-dashboard') ? 'active' : ''); ?>"
              @click="sidebarOpen = false">
            <i class="fas fa-home w-5 mr-3"></i>
              Dashboard
          </a>

          <a href="<?php echo e(route('admin.tournaments.index')); ?>"
            class="admin-nav-link <?php echo e(Route::is('admin.tournaments.index') ? 'active' : ''); ?>"
                @click="sidebarOpen = false">
            <i class="fas fa-calendar w-5 mr-3"></i>
            Tournaments
          </a>

          <a href="<?php echo e(route('admin.players.index')); ?>"
            class="admin-nav-link <?php echo e(Route::is('admin.players.index') ? 'active' : ''); ?>"
                @click="sidebarOpen = false">
              <i class="fa-regular fa-id-badge w-5 mr-3"></i>        
              Players
          </a>

          <a href="<?php echo e(route('admin.blog.index')); ?>"
            class="admin-nav-link <?php echo e(Route::is('admin.blog.index') ? 'active' : ''); ?>"
              @click="sidebarOpen = false">
              <i class="fa-regular fa-newspaper w-5 mr-3"></i>        
              Blog
          </a>

          <a href="<?php echo e(route('admin.course-details.index')); ?>"
                class="admin-nav-link <?php echo e(Route::is('admin.course-details.index') ? 'active' : ''); ?>"
                @click="sidebarOpen = false">
                <i class="fa-solid fa-flag w-5 mr-3"></i>
                Courses
            </a> 

          <a href="<?php echo e(route('admin.tee-assignments.index')); ?>"
                class="admin-nav-link <?php echo e(Route::is('admin.tee-assignments.index') ? 'active' : ''); ?>"
                @click="sidebarOpen = false">
                <i class="fa-solid fa-golf-ball-tee w-5 mr-3"></i>
                Tee Times
            </a> 
        </nav>

        <div class="px-4 py-6">
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="admin-nav-link logout w-full">
                        <i class="fas fa-sign-out-alt mr-2"></i>
                        Logout
                    </button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="admin-nav-link logout w-full">
                    <i class="fas fa-sign-in-alt mr-2"></i>Login
                </a>
            <?php endif; ?>
        </div>
    </aside>

    <!-- Page Content -->
    <main class="md:pl-[270px] p-10 overflow-y-auto transition-all">
        <div class="bg-white shadow-lg p-3 rounded-2xl overflow-y-auto">
            <header class="h-14 flex items-center justify-between px-4">
                <div class="text-lg font-semibold text-gray-700">
                    <?php echo e($title ?? 'Dashboard'); ?>

                </div>
                <div class="flex items-center space-x-4">
                    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </header>

            <?php echo e($slot); ?>

        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
</body>
</html>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\components\admin-nav.blade.php ENDPATH**/ ?>