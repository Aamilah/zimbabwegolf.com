<?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => ['title' => 'Add Hole Details for ' . $courseDetail->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Add Hole Details for ' . $courseDetail->name)]); ?>
    <div class="p-4">
        <?php if (isset($component)) { $__componentOriginal3720980d10c794fab505e92af7bcadba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3720980d10c794fab505e92af7bcadba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.file-section-bg','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('file-section-bg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form action="<?php echo e(route('admin.course-holes.store', $courseDetail->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <ul class="px-4 py-2 bg-red-100 rounded mb-4">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="my-2 text-red-500"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>

                <div class="overflow-x-auto">
                    <table class="admin-table">
                        <thead class="bg-green-200">
                            <tr>
                                <th class="px-4 py-2 border">Hole Number</th>
                                <th class="px-4 py-2 border">Par</th>
                                <th class="px-4 py-2 border">Yardage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $holeNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2 border text-center"><?php echo e($hole); ?></td>
                                    <td class="px-4 py-2 border">
                                        <input type="number" name="par[]" class="form-input w-full" placeholder="Par" min="3" max="6" required>
                                    </td>
                                    <td class="px-4 py-2 border">
                                        <input type="number" name="yardage[]" class="form-input w-full" placeholder="Yardage" min="50" max="700" required>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="my-4 text-right">
                    <button class="green-red-btn">
                        Save Hole Details <span><i class="fa-solid fa-check"></i></span>
                    </button>
                </div>

            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3720980d10c794fab505e92af7bcadba)): ?>
<?php $attributes = $__attributesOriginal3720980d10c794fab505e92af7bcadba; ?>
<?php unset($__attributesOriginal3720980d10c794fab505e92af7bcadba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3720980d10c794fab505e92af7bcadba)): ?>
<?php $component = $__componentOriginal3720980d10c794fab505e92af7bcadba; ?>
<?php unset($__componentOriginal3720980d10c794fab505e92af7bcadba); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\zga_project\resources\views\admin\course_holes\create.blade.php ENDPATH**/ ?>