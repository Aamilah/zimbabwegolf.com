<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<section class="news-hero">
  <div id="news-carousel" class="my-slider">
    <?php $__currentLoopData = $recentArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if (isset($component)) { $__componentOriginaleca602c47634567753e2c7d5c48777c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleca602c47634567753e2c7d5c48777c0 = $attributes; } ?>
<?php $component = App\View\Components\NewsCarouselItem::resolve(['blog' => $article] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('news-carousel-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\NewsCarouselItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('blog.show', $article->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleca602c47634567753e2c7d5c48777c0)): ?>
<?php $attributes = $__attributesOriginaleca602c47634567753e2c7d5c48777c0; ?>
<?php unset($__attributesOriginaleca602c47634567753e2c7d5c48777c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleca602c47634567753e2c7d5c48777c0)): ?>
<?php $component = $__componentOriginaleca602c47634567753e2c7d5c48777c0; ?>
<?php unset($__componentOriginaleca602c47634567753e2c7d5c48777c0); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>



<section class="news-updates">
  <div class="container">
    <div class="section-title text-center">
      <h2>What’s The Latest Updates</h2>
      <p>Stay up to date with what is happening in the world of golf in Zimbabwe</p>
    </div>
    <div class="content">
      <div class="columns-2 gap-4 sm:columns-3 sm:gap-8 my-4">
        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if (isset($component)) { $__componentOriginale11fb6f522b418983a9a50d6717c025b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale11fb6f522b418983a9a50d6717c025b = $attributes; } ?>
<?php $component = App\View\Components\PostThumbnailTwo::resolve(['blog' => $blogs] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('post-thumbnail-two'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PostThumbnailTwo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('blog.show', $blogs->slug)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale11fb6f522b418983a9a50d6717c025b)): ?>
<?php $attributes = $__attributesOriginale11fb6f522b418983a9a50d6717c025b; ?>
<?php unset($__attributesOriginale11fb6f522b418983a9a50d6717c025b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale11fb6f522b418983a9a50d6717c025b)): ?>
<?php $component = $__componentOriginale11fb6f522b418983a9a50d6717c025b; ?>
<?php unset($__componentOriginale11fb6f522b418983a9a50d6717c025b); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
        <?php echo e($blog->links('vendor.pagination.main')); ?>

    </div>
  </div>
</section>

<section class="pre-footer">
    <div class="frame red-bg">
        <div class="text">
            <h2>Stay on top of the game</h2>
            <p>Every event is more than just a game — it's a chance to grow, to lead, and to make your mark on Zimbabwe’s golfing legacy. Join our tournaments, represent your club, and challenge yourself among the nation’s finest. The journey starts with one swing, one round, one opportunity.</p>
        </div>
        <div class="box gold-bg">
            <h4>
                CONTACT US
            </h4>
            <p>Want to make an enquiry about an event? or sign up for a tournaments do not hesitate to contact us for more details</p>
            <button class="green-red-btn"><a href="">Learn More <span><i class="fa-solid fa-arrow-up fa-rotate-by" style="--fa-rotate-angle: 45deg;"></i></span></a></button>
        </div>
    </div>
</section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Herd\zga_project\resources\views\blog\index.blade.php ENDPATH**/ ?>